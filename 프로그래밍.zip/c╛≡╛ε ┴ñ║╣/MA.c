#include<stdio.h>

int main()
{
	int a,b, i,j;
	scanf("%d %d", &a, &b);
	int n[a][b];
	int k[a][b];
	int s[a][b];
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d ", &n[i][j]);
		}
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d ", &k[i][j]);
		}
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			s[i][j]=n[i][j]+k[i][j];
			printf("%d ",s[i][j]);
		}
		printf("\n");
	}
}
