#include<stdio.h>

void to_binary_n(unsigned long n, int b)
{
	int r;
	r=n%b;
	if(n>=b)
		to_binary_n(n/b,b);
	printf("%d", r);
	
	return;
}

int main()
{
	unsigned long n;
	int a;
	scanf("%d %d", &n, &a);
	to_binary_n(n,a);
}

