#include<stdio.h>


void H()
{
	printf("Hello, World.");
}
void K()
{
	printf("Kyungsung University.");
}
void D()
{
	printf("Dept. of Computer Science.");
}
void B()
{
	printf(" ");
}
void n()
{
	printf("\n");
}
int main()
{
	H(), n(), H(), n(), H(), B(), K(), n(), K(), n(), K(), B(), D(), n(), H(), B(), K(), B(), D();
	
	return 0;
}
