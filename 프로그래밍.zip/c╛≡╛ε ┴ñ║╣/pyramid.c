#include<stdio.h>

int main()
{
	char ch[30];
	scanf("%s", &ch);
	int a, i, j, k, s;
	s=strlen(ch);
	for(i=s;i>0;i--)
	{
		for(k=s-i;k>0;k--)
		{
			printf("-");
		}
		for(j=s-i;j<s;j++)
		{
			printf("%c",ch[j]);
		}
		for(j-=2;j>=s-i;j--)
		{
			printf("%c",ch[j]);
		}
		for(k=strlen(ch)-i;k>0;k--)
		{
			printf("-");
		}
		printf("\n");
	}
}
