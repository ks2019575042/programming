#include <stdio.h>

int main()

{
	float a;
	double b;
	b = 1234567.890123;
	a = b;
	printf("%f %lf", a, b);
	
	return 0;
}
