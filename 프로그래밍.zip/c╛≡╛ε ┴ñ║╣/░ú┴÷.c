#include<stdio.h>

int main()
{
	int year,k,g;
	scanf("%d",&year);
	k=year%10;
	g=year%12;
	printf("%c%d",65+k,g);
	return 0;
}
