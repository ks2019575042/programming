#include<stdio.h>

int main()
{
	long long int a, b, c, d, s=0;
	
	scanf("%lld %lld", &a, &b);
	c=a-b;
	d=a+b;
	while (c!=d+1)
	{
		s=s+c;
		c++;
	}
	printf("%lld",s);
}
