#include<stdio.h>


double harmonic(double a,double b)
{
	double res=0;
	res=2/((a+b)/(a*b));
	return res;
}
int main()
{
	double a,b, r;
	while((scanf("%lf %lf",&a,&b))==2)
	{
		r=harmonic(a,b);
		printf("%.3lf\n",r);
	}
}
