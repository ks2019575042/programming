#include<stdio.h>

int main()
{
	float M, G;
	const float L=3.785, K=1.609;
	scanf("%f %f", &M, &G);
	printf("%.1f mpg or %.1f liters / 100km.", M/G, (100*L*G)/(K*M));
	
	return 0;
}
