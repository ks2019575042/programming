#include<stdio.h>

int main()
{
	int n,i, k, m=0, s, z, z2;
	int a[10000]={0,};
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&k);
		a[k]++;
	}
	for(s=0;s<10000;s++)
	{
		if(a[s]>m)
		{
			z=s;
			m=a[s];
		}
		else if(a[s]==m)
		{
			z=s;
		}
	}
	printf("%d %d",z, m);

}
