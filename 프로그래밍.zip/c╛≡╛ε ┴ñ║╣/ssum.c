#include<stdio.h>
#include<stdlib.h>

int com(const void *q1, const void *q2)
{
	int num1 = *(int*)q1;
	int num2 = *(int*)q2;
	
	if (num1 > num2)
		return 1;
	else if (num1 < num2)
        return -1;
    else
    	return 0;
}
int main()
{
	int a, i, s=0, k1, k2, k3;
	scanf("%d %d %d %d",&a, &k1, &k2, &k3);
	int k[a];
	for(i=0;i<a;i++)
	{
		scanf("%d", &k[i]);
	}
	qsort(k,a,sizeof(int),com);
	s=k[k1-1]+k[k2-1]+k[k3-1];
	printf("%d", s);
	
}
