#include <stdio.h>
int main()
{
	long long i,j,x,countx=0,county=0;
	scanf("%lld",&x);
	for(i=3; i<=x; i+=2)
	{
		for(j=1; j<=i; j++)
		{
			if(i%j==0)
			{
				countx++;
			}
		}
		if(countx==2)
		{
			county++;
		}
	}
	printf("%lld",county);
}
