#include<stdio.h>

int main()
{
	double n, sum=0;
	int a, i;
	scanf("%lf %d", &n, &a);
	for(i=1;i<=a;i++)
	{
		if(i%2==0)
		{
		sum-=(n*n)/i;
		}
		else
		sum+=(n*n)/i;
	}
	printf("%.5lf", sum);
}
