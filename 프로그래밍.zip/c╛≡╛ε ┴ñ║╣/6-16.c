#include<stdio.h>

int main()
{
	double a, b, c, k, i;
	scanf("%lf %lf %lf",&a, &b, &c);
	for(i=0;i<c;i++)
	{
		k=a*b;
		a+=k;
	}
	printf("%.5lf",a);
}
