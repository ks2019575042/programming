#include<stdio.h>

unsigned long long f(int n)
{
	unsigned long long first=1, second=1, r=1;
	while(n-- > 2)
	{
		r=first+second;
		first=second;
		second=r;
	}
	return r;
}
int main()
{
	int a;
	while(scanf("%d",&a))
	{
		if(a<0)
		break;
		if(a==0)
		printf("#%d: 0\n",a);
		else
		printf("#%d: %llu\n", a, f(a));
	}
}
