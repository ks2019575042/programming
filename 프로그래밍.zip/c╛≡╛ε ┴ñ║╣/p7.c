#include<stdio.h>

int main()
{
	long long int a, b;
	scanf("%lld\n%lld",&a,&b);
	printf("%lld",a+b);
	
	return 0;
}
