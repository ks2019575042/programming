#include<stdio.h>

int main()
{
	int i=1,h,m;
	while(i>0)
	{		
		scanf("%d",&i);
		h=i/60;
		m=i%60;
		printf("Time in minute(s) : %4d = %2d hour(s) and %2d minutes\n", i, h ,m);
	}
}
