#include<stdio.h>

int main()
{
	int x;
	scanf("%d",&x);
	printf("%d is the ASCII code for %c.",x,x);
}
