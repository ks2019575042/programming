#include <stdio.h>

int main()

{
	double mile, gallon, liter, km, mpg;
	scanf("%lf %lf", &mile, &gallon);
	liter = (gallon*3.785)/(mile*1.609)*100.0;
	km = mile*1.609;
	mpg = mile/gallon;
	printf("%.1lf mpg or %.1lf liters / 100Km.", mpg, liter);
	
	return 0;
}
