#include <stdio.h>
#include <math.h>

int main()

{
	double a, b, c, d;
	double e = sqrt(d);
	scanf("%lf %lf %lf", &a, &b, &c);
	d = ((a+b+c)*(b+c-a)*(a+c-b))/8;
	
	if(a>b+c || b>=a+c || c>=a+b)
	{
		printf("Not a Triangle");
	}
	else if(a==b+c || b==a+c || c==a+b)
	{
		printf("0");
	}
	else
	{
		printf("%.2lf", e);
	}
	
	return 0;
}
