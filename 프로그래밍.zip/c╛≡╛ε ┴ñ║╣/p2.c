#include <stdio.h>

int main()
{
	printf("Hello, world!\nKyungsung University\nDept. of Computer Science");
	
	return 0;
}
