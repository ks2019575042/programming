#include<stdio.h>
#include<math.h>

int main(void)
{
	double a, b ,c, s, m;
	scanf("%lf %lf %lf", &a, &b, &c);
	
	s=(a+b+c)/2;
	
	if ((a-b>c)||(b-a>c)||(c-a>b))
	{
		printf("Not a Triangle");
	}
	else if ((a-b==c)||(b-a==c)||(c-a==b))
	{
		printf("0.00");
	}
	else
	{
		m=sqrt(s*(s-a)*(s-b)*(s-c));
		printf("%.2lf",m);
	}
	
	return 0;
}
