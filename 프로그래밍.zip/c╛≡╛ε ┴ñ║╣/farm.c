#include<stdio.h>

int main()
{
	int a,b,n,w,i,j,i2=0,j2=0,sheep=0,goat=0;
	scanf("%d %d %d %d", &a, &b, &n, &w);
	for(i=1;i<=n;i++)
	{
		j=n-i;
		if((i*a+j*b)==w)
		{
			sheep=i;
			goat=j;
			break;
		}
	}
	for(i=i+1;i<=n;i++)
	{
		j=n-i;
		if((i*a+j*b)==w)
		{
			i2=i;
			j2=j;
			break;
		}
	}
	if(i2!=0&&j2!=0)
	printf("-1");
	else if(sheep==0&&goat==0)
	printf("-1");
	else
	printf("%d %d",sheep,goat);
}
