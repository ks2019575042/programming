#include<stdio.h>

void asd(double *x,double *y, double *z)
{
	double k;
	if(*x > *y)
	{
		k = *x;
		*x = *y;
		*y = k;
	}
	if(*y > *z)
	{
		k = *y;
		*y = *z;
		*z = k;
	}
	if(*x > *y)
	{
		k = *x;
		*x = *y;
		*y = k;
	}
	return;
}
int main()
{
	double a,b,c;
	while((scanf("%lf %lf %lf",&a,&b,&c))==3)
	{
		asd(&a,&b,&c);
		printf("%lf %lf %lf\n",a,b,c);
	}
}
