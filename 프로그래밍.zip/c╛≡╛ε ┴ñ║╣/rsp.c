#include<stdio.h>

int rsp(char *a,char *b, int n, int k)
{
	int i, j, cnt=0, max=0;
	for(i=0;i<n;i++)
	{
		cnt=0;
		for(j=0;j<k;j++)
		{
			if(j+i>n)
			break;
			else
			{
				if(a[j+i]=='R' && b[j]=='P')
				cnt++;
				if(a[j+i]=='P' && b[j]=='S')
				cnt++;
				if(a[j+i]=='S' && b[j]=='R')
				cnt++;	
			}
		}
		if(max<=cnt)
		max=cnt;
	}
	return max;
}
int main()
{
	int n, k, i, cnt;
	scanf("%d %d\n", &n, &k);
	char a[n], b[k];
	scanf("%s\n",a);
	scanf("%s",b);
	
	cnt=rsp(a,b,n,k);
	printf("%d", cnt);
}
