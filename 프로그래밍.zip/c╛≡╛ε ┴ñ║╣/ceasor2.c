#include<stdio.h>
#include<string.h>

int main()
{
	int k, i, n;
	char c[80] , t[80] , r[80];
	scanf("%d", &k);
	scanf("%s %s %s",&c, &t, &r);
	for(i=0;i<strlen(c);i++)
	{
		if(c[i]-k<'A')
		{
			c[i]='Z'+c[i]-64-k;
		}
		else
		c[i]=c[i]-k;
	}
	for(i=0;i<strlen(t);i++)
	{
		if(t[i]-k<'A')
		{
			t[i]='Z'+t[i]-64-k;
		}
		else
		t[i]=t[i]-k;
	}
	for(i=0;i<strlen(r);i++)
	{
		if(r[i]-k<'A')
		{
			r[i]='Z'+r[i]-64-k;
		}
		else
		r[i]=r[i]-k;
	}
	printf("%s %s %s", c, t, r);
}
