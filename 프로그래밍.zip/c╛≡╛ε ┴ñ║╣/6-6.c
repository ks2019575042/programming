#include<stdio.h>

int main()
{
	long long int n, k, i;
	scanf("%lld %lld", &n, &k);
	for(i=n;i<=k;i++)
	{
		printf("%lld %lld %lld\n", i, i*i, i*i*i); 
	}
}
