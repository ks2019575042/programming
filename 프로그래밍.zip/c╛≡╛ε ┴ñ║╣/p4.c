#include<stdio.h>

int main()
{
	int x=0;
	scanf("%d",&x);
	printf("An age of %d years is %d days.",x,x*365);
	
	return 0;
}
