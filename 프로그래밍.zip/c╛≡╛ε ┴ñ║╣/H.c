#include<stdio.h>

double H(double a[], int n)
{
	int i;
	double h, b=0;
	for(i=0;i<n;i++)
	{
		b+=1/a[i];
	}
	h=(double)n/b;
	return h;
}
int main()
{
	int n,i;
	while(scanf("%d",&n))
	{
		if(n==0)
		break;
		double k[n];
		for(i=0;i<n;i++)
		{
			scanf("%lf",&k[i]);
		}
		printf("%.3lf\n", H(k,n));
	}
}
