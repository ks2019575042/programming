#include<stdio.h>

long long int p(int a, int b)
{
	int n;
	n=p(a-1,b-1)+p(a-1,b);
	
	return n;
}
int main()
{
	int a,b;
	scanf("%d %d", &a, &b);
	printf("%lld", p(a,b));
}
