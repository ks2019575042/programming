#include<stdio.h>

int main()
{
	char S[30],N[30];
	scanf("%s %s", &S, &N);
	printf("%s %s\n",S,N);
	printf("%4d %7d\n",strlen(S),strlen(N));
	printf("%s %s\n",S,N);
	printf("%-4d %-7d",strlen(S),strlen(N));
}
