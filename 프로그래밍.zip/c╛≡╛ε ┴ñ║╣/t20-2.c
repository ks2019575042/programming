#include <stdio.h>
#include <math.h>

int main()
{
	int a, b, c;
	double s, area;
	scanf("%d %d %d", &a, &b, &c);
	s = (a+b+c)/2.0;
	
	if(a>b+c || b>a+c || c>a+b)
	{
		printf("Not a Triangle");
	}
	else if(a==b+c || b==a+c || c==a+b)
	{
		printf("%.2lf", 0);
	}
	else
	{
		area = sqrt(s*(s-a)*(s-b)*(s-c));
		printf("%.2lf", area);
	}
	return 0;
}
