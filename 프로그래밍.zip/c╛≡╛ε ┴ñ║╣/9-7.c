#include<stdio.h>

int letter(char l)
{
	int k=0;
	if(l>='a')
	k=l-'a';
	else if(l>='A')
	k=l-'A';
	else if(l=='\n'||l==' ')
	k=0;
	else
	k=-1;
	return k;
}
int main()
{
	int a=0;
	char l;
	while((l=getchar())!=EOF)
	{
		a=letter(l);
		if(a>0)
		printf("%c is a letter #%d.\n",l,a+1);
		else if(a<0)
		printf("%c is not a letter.\n",l);
	}
	return 0;
}
