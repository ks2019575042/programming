#include<stdio.h>
#include<stdlib.h>

int compare(const void *q1, const void *q2)
{
	int num1 = *(int*)q1;
	int num2 = *(int*)q2;
	
	if (num1 > num2)
		return 1;
	else if (num1 < num2)
        return -1;
    else
    	return 0;
}
int main()
{
	int a, i, cnt=0;
	scanf("%d\n",&a);
	int k[a];
	for(i=0;i<a;i++)
	{
		scanf("%d",&k[i]);
	} 
	
	qsort(k,a,sizeof(int),compare);
	
	for(i=0;i<a;i++)
	{
		
	}
}
