#include<stdio.h>

int sc(int *a, int n)
{
	int s,i, m=10000000, m2=10000000;
	for(i=0;i<n;i++)
	{
		if(m> a[i])
		{
			m2=m;
			m=a[i];
		}
		else if(m2>a[i])
		{
			m2=a[i];
		}
	}
	return m2;
	
}
int main()
{
	int n, i, s;
	scanf("%d", &n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d", &a[i]);
	}
	s=sc(a, n);
	printf("%d", s);
}
