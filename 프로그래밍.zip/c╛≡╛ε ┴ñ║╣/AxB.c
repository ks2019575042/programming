#include<stdio.h>

int main()
{
	long long int x, y;
	scanf("%lld %lld", &x, &y);
	printf("%lld",x*y);
	
	return 0;
}
