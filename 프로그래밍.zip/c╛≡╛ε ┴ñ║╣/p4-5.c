#include<stdio.h>

int main()
{
	float bit, file;
	scanf("%f %f",&bit, &file);
	printf("%.2fsec", (8*file)/bit);
	
}
