#include<stdio.h>

void chline(char ch, int i,int j);

int main()
{
	char ch;
	int i,j;
	scanf("%c %d %d",&ch,&i,&j);
	chline(ch,i,j);
	return 0;
}
void chline(char ch, int i,int j)
{
	int s;
	for(s=0;s<i-1;s++)
	{
		printf("+");
	}
	for(;s<j;s++)
	{
		printf("%c",ch);
	}
	for(s=0;s<i-1;s++)
	{
		printf("+");
	}
}
