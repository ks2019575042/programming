#include<stdio.h>

int main()
{
	int a,b,i;
	long long int sum=0;
	scanf("%d",&a);
	for(i=1;i<=a;i++)
	{
		scanf("%d",&b);
		sum+=b;
	}
	printf("%lld",sum);
}
