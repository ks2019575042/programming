#include<stdio.h>

int main()
{
	double x=0;
	scanf("%lf",&x);
	printf("%.2lf",x*2.54);
	
	return 0;
}
