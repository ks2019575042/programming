#include<stdio.h>

int main()
{
	int year,gan,ez;
	scanf("%d",&year);
	gan=(year+6)%10;
	ez=(year+8)%12;
	printf("%c%d",'A'+ez, gan);
	
}
