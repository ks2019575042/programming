#include <stdio.h>

int main()

{
	int j, a;
	scanf("%d", &j);
	for(int a = 0; a < j; a++)
	{
		for(int b = 0; b <= a; b++)
		{
			printf("$");
		}
		printf("\n");
	}
	return 0;
}
