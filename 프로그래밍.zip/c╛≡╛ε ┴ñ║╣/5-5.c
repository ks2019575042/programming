#include<stdio.h>
#define money 1000
int main()
{
	long long int d, i, sum=0;
	scanf("%lld", &d);
	for(i=0 ;i<=d ;i++)
	{
		sum += i*money;
	}
	printf("%lld",sum);
}
