#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c,d;
	while(scanf("%lf %lf %lf", &a,&b,&c))
	{
		if(b*b-4*a*c<0)
		printf("Imaginary root\n");
		else if(b*b-4*a*c==0)
		{
			printf("%.3lf\n",(b*-1)/(2*a));
		}
		else
		{
			d=sqrt(b*b-4*a*c);
			printf("%.3lf %.3lf\n",(b*(-1)+d)/(2*a) , (b*(-1)-d)/(2*a));
		}
	}
}
