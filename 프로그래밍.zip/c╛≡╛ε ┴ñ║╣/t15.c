#include <stdio.h>

int main()

{
	double x, y, z;
	scanf("%f %f", x, y);
	x = (y*8)/z;
	printf("%.2f sec",z);
	
	return 0;
}
