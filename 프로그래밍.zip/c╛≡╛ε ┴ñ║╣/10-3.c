#include<stdio.h>
#include<string.h>

int max(int *a, int n)
{
	int i, m=a[0];
	for(i=1;i<n;i++)
	{
		if(m<=a[i])
		m=a[i];
	}
	return m;
}
int main()
{
	int a[100000], i=0, m, n;
	
	while((scanf("%d",&a[i]))!=EOF)
	{	
		i++;
	}
	m=max(a,i);
	printf("%d",m);
}
