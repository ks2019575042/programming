#include<stdio.h>

int main()
{
	int k, i, j;
	scanf("%d", &k);
	int a[k];
	for(i=0;i<=k;i++)
	{
		scanf("%d", &a[i]);
	}
	for(j=k-1;j>=0;j--)
	{
		printf("%d ",a[j]);
	}
}
