#include<stdio.h>

int main()
{
	int i, m, al, n, j, k;
	scanf("%c", &al);
	n=al-'A';
	for(i=0;i<=n;i++)
	{
		for(m=0;m<n-i;m++)
		{
			printf("-");
		}
		for(j=n;j>=n-i;j--)
		{
			printf("%c",al-j);
		}
		for(k=1;k<=i;k++)
		{
			printf("%c",al-n+i);
		}
		printf("\n");
	}
}
