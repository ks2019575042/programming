#include<stdio.h>

int main()
{
	double j, sump=0, summ=0;
	int a, i;
	scanf("%d", &a);
	for(i=1;i<=a;i++)
	{
		j=i;
		sump+=1/j;
	}
	for(i=1;i<=a;i++)
	{
		j=i;
		if((i%2)==1)
			summ+=1/j;
		else
			summ-=1/j;
	}
	printf("%.5lf %.5lf",sump ,summ);
}
