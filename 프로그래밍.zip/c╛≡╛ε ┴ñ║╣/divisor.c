#include<stdio.h>

int main()
{
	int n, cnt=0, i ,j;
	scanf("%d", &n);
	for(i=2;i*2<=n;i++)
	{
		if((n%i)==0)
		{
			cnt++;
		}
	}
	printf("%d",cnt);
	return 0;
}
