#include<stdio.h>

int main()
{
	int k, i;
	char c[80] , t[80] , r[80];
	scanf("%d", &k);
	scanf("%s %s %s",&c, &t, &r);
	for(i=0;i<strlen(c);i++)
	{
		c[i]=c[i]-k;
	}
	for(i=0;i<strlen(t);i++)
	{
		t[i]=t[i]-k;
	}
	for(i=0;i<strlen(r);i++)
	{
		r[i]=r[i]-k;
	}
	printf("%s %s %s", c, t, r);
}
