#include<stdio.h>

int main()
{
	double a, c;
	scanf("%lf",&a);
	c=950*a;
	printf("%e",c/(3.0e-23));

	return 0;	
}
