#include<stdio.h>

int main()
{
	int a, sump, summ, i;
	scanf("%d", &a);
	for(i=1;i<=a;i++)
	{
		sump+=1/i;
	}
	for(i=1;i<=a;i++)
	{
		if((i%2)==1)
		summ+=1/i;
		else
		summ-=1/i;
	}
	printf("%d %d",sump ,summ);
}
