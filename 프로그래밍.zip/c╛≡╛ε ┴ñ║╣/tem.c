#include<stdio.h>

int main()
{
	double k, s, h;
	scanf("%lf", &k);
	s=k-273.16;
	h=s*9/5+32;
	printf("%.2lf %.2lf",h,s);
	
}
