#include<stdio.h>
#include<stdlib.h>

int qs(const void *a, const void *b)
{
	int num1=*(int*)a;
	int num2=*(int*)b;
	if(num1<num2)
		return -1;
	else if(num1>num2)
		return 1;
	else
		return 0;
}
int main()
{
	int n, b, i, z, v;
	double sum=0, sum2=0;
	scanf("%d %d", &n, &b);
	int s[n];
	for(i=0;i<n;i++)
	{
		scanf("%d", &s[i]);
	}
	qsort(s,n,sizeof(int),qs);
	for(z=b;z<n-b;z++)
	{
		sum+=s[z];
	}
	for(v=0;v<b;v++)
	{
		s[v]=s[b];
		s[n-v-1]=s[n-b-1];
	}
	for(i=0;i<n;i++)
	{
		sum2+=s[i];
	}
	printf("%.1lf %.1lf", sum/(n-2*b), sum2/n);
}
