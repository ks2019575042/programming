#include<stdio.h>

int main()
{
	int n, cnt=0, a;
	scanf("%d", &n);
	while(n!=1)
	{
		if(n%2==0)
		{
			n=n/2;
		}
		else
		{
			n=3*n+1;
		}
		cnt++;
	}
	printf("%d",cnt-1);
}
