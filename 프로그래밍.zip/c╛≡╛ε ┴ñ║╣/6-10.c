#include<stdio.h>

int main()
{
	int a, b, sum=0, i;
	while(scanf("%d %d",&a,&b)==2&&a<b)
	{
		sum=0;
		for(i=a;i<=b;i++)
		{
			sum+=i*i;
		}
		printf("%d\n",sum);
	}
}
