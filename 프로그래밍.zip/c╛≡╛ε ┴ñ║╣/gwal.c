#include<stdio.h>
#include<string.h>

int main()
{
	int i,n=0;
	char g[100];
	scanf("%s",&g);
	for(i=0;i<strlen(g);i++)
	{
		if(g[i]=='(')
		n++;
		else if(g[i]==')'&&n==0)
		{
			n++;
			break;
		}
		else if(g[i]==')')
		n--;
	}
	if(n==0)
	printf("YES");
	else
	printf("NO");
}
