#include <stdio.h>
void to_binary (unsigned long int n, int b);

int main()
{
	unsigned long int n;
	int b;
	scanf("%ul %d", &n, &b);
	to_binary(n, b);
}

void to_binary (unsigned long int n, int b)
{
	int r;
	r = n % b;
	if (n >= b)
	{
		to_binary ((n / b), b);
	}
	putchar ('0' + r);
	printf("%d", r);
	
	return ;
}
