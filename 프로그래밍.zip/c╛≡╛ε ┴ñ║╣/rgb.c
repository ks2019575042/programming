#include<stdio.h>

int main()
{
	int r=0,g=0,b=0;
	char a;
	while((a=getchar())!=EOF)
	{
		if(a=='R')
		r++;
		if(a=='G')
		g++;
		if(a=='B')
		b++;
	}
	printf("%d %d %d",r,g,b);
}
