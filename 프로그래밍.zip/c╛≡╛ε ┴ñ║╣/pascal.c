#include<stdio.h>

long long int p[60][60];

int main()
{
	int i,j;
	for(i=0;i<60;i++)
	{
		p[i][i]=1;
		p[i][0]=1;
	}
	for(i=1;i<60;i++)
	{
		for(j=0;j<i;j++)
		{
			if(i!=j&&j!=0)
			p[i][j]=p[i-1][j]+p[i-1][j-1];
		}
	}
	/*for(i=58;i<=59;i++)
	{
		for(j=29;j<=31;j++)
		{
			printf("%lld ",p[i][j]);
		}
		printf("\n");
	}*/
	int a,b;
	scanf("%d %d",&a, &b);
	printf("%lld",p[a-1][b-1]);
}
